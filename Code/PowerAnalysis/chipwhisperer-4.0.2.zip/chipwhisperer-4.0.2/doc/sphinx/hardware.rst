.. _hardware:

Hardware Setup
==============

Contents:

.. toctree::
    :maxdepth: 2
    
    hwftdi
    hwvisascope
    hwpicoscope


