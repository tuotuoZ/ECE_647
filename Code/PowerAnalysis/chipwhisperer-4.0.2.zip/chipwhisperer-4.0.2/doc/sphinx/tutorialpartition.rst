.. _tutorialpartition:

Tutorial #B4: Testing Two Partitions of Traces
==============================================

This tutorial will introduce you to the idea of partioning traces into several
groups in order to help detect leakage.

Finding General Leakage
-----------------------

TODO

Determining the Type of Leakage
-------------------------------

TODO

