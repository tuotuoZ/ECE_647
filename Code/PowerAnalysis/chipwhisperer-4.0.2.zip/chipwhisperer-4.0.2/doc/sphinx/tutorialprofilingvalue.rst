.. _tutorialprofilingvalue:

Tutorial #B8: Profiling Attacks (key value direct)
==================================================

This tutorial will more directly attack the encryption key. A fairly basic
attack will be used which requires a fixed plaintext.

*TODO: This attack is incomplete*










