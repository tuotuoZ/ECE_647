chipwhisperer.capture.auxiliary package
=======================================

Submodules
----------

chipwhisperer.capture.auxiliary.AuxiliaryTemplate module
--------------------------------------------------------

.. automodule:: chipwhisperer.capture.auxiliary.AuxiliaryTemplate
    :members:
    :undoc-members:
    :show-inheritance:

chipwhisperer.capture.auxiliary.FrequencyMeasure module
-------------------------------------------------------

.. automodule:: chipwhisperer.capture.auxiliary.FrequencyMeasure
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: chipwhisperer.capture.auxiliary
    :members:
    :undoc-members:
    :show-inheritance:
