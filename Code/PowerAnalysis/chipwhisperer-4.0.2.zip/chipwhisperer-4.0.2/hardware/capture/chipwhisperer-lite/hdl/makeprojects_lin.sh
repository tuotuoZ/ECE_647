#!/bin/bash
python ../../../../openadc/hdl/makeise/makeise.py cwlite.in cwlite_ise/cwlite_ise.xise


