The 'Digikey BOM' allows you to just upload the BOM straight to Digikey. Part quantities have been "rounded up" to give you
extra resistors, capacitors, LEDs, and similar very small parts. You can go through an further round up if you want.

In addition Digikey will print the PCB ref designator right on the parts label. See the blog post for details.