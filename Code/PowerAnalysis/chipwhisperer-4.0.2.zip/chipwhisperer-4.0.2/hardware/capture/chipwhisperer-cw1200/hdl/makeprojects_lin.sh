#!/bin/bash
python ../../../../openadc/hdl/makeise/makeise.py cw1200.in cw1200_ise/cw1200_ise.xise

